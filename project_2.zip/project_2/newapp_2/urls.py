from django.urls import path
from newapp_2 import views
urlpatterns=[
    path('index/',views.index),
    path('Great_India/',views.great_india),
    path('Exam_Form/',views.Exam_Form),
]