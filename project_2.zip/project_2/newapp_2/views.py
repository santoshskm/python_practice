from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'newapp_2/The_Great_India.html')
def great_india(request):
    return render(request,'newapp_2/The_Great_India.html')
def Exam_Form(request):
    return render(request,'newapp_2/exam_form.html')