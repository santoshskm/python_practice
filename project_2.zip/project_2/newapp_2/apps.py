from django.apps import AppConfig


class Newapp2Config(AppConfig):
    name = 'newapp_2'
